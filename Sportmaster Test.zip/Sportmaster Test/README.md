[![Build Status](https://travis-ci.com/pentogono/sportmaster-bonus-service.svg?branch=master)](https://travis-ci.com/pentogono/sportmaster-bonus-service)[![codecov](https://codecov.io/gh/pentogono/sportmaster-bonus-service/branch/master/graph/badge.svg)](https://codecov.io/gh/pentogono/sportmaster-bonus-service)

# Sportmaster Bonus Service
